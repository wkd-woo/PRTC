# REST API 실험실
API REST를 경험해보기 위한 실험실입니다.

1. node.js 를 설치합니다.
1. npm i -g json-server 
1. json-server 실행
1. localhost:3000 접속해서 홈페이지에서 안내하는 내용을 따라 합니다. 